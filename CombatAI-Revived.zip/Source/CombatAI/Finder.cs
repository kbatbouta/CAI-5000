﻿using System;
using HarmonyLib;

namespace CombatAI
{
    public static class Finder
    {
        public static Harmony Harmony;
        public static CombatAIMod Mod;
        public static Settings Settings;                
    }
}

