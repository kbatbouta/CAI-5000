﻿using System;
using Verse;
namespace CombatAI
{
    public class CompProperties_AnimalAI : CompProperties
    {        
        public CompProperties_AnimalAI()
        {
            compClass = typeof(ThingComp_AnimalAI);
        }        
    }
}

